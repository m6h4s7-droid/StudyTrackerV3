package com.studytracker.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DailyGoalAlarmReceiver extends BroadcastReceiver {
    private static final String PREFS = "study_tracker_native";
    private static final String STATE_KEY = "synced_state";

    public static void scheduleNext(Context context) {
        Calendar next = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
        next.set(Calendar.HOUR_OF_DAY, 3);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(context, DailyGoalAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 303, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            else alarm.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        try {
            String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(STATE_KEY, null);
            if (raw != null) {
                JSONObject state = new JSONObject(raw);
                JSONObject goals = state.optJSONObject("dailyGoals");
                JSONObject current = goals == null ? null : goals.optJSONObject("current");
                if (current != null && !"finished".equals(current.optString("status"))) {
                    Calendar cutoff = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka"));
                    cutoff.add(Calendar.HOUR_OF_DAY, -3);
                    String todayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US) {{ setTimeZone(TimeZone.getTimeZone("Asia/Dhaka")); }}.format(cutoff.getTime());
                    String goalDate = current.optString("date", "");
                    if (!goalDate.isEmpty() && !goalDate.equals(todayKey)) {
                        String track = current.optString("track", "du");
                        JSONArray checked = current.optJSONArray("checked");
                        if (checked == null) checked = new JSONArray();
                        JSONArray items = current.optJSONArray("items");
                        JSONArray skipped = new JSONArray();
                        if (items != null) {
                            for (int i = 0; i < items.length(); i++) {
                                String itemKey = items.optString(i);
                                boolean wasChecked = false;
                                for (int j = 0; j < checked.length(); j++) {
                                    if (itemKey.equals(checked.optString(j))) { wasChecked = true; break; }
                                }
                                if (!wasChecked) skipped.put(itemKey);
                            }
                        }
                        if (state.optBoolean("incompleteGoalMessage", true) && skipped.length() > 0) {
                            JSONObject notice = new JSONObject();
                            notice.put("date", goalDate);
                            notice.put("track", current.optString("track", "du"));
                            notice.put("skipped", skipped);
                            state.put("pendingGoalNotice", notice);
                        }
                        JSONObject done = state.optJSONObject("done"); if (done == null) done = new JSONObject();
                        JSONArray doneTrack = done.optJSONArray(track); if (doneTrack == null) doneTrack = new JSONArray();
                        JSONObject completedAt = state.optJSONObject("completedAt"); if (completedAt == null) completedAt = new JSONObject();
                        JSONObject trackDates = completedAt.optJSONObject(track); if (trackDates == null) trackDates = new JSONObject();
                        JSONObject activity = state.optJSONObject("activity"); if (activity == null) activity = new JSONObject();
                        int added = 0;
                        for (int i = 0; i < checked.length(); i++) {
                            String key = checked.optString(i);
                            boolean exists = false;
                            for (int j = 0; j < doneTrack.length(); j++) if (key.equals(doneTrack.optString(j))) { exists = true; break; }
                            if (!exists) { doneTrack.put(key); trackDates.put(key, goalDate); activity.put(goalDate, activity.optInt(goalDate, 0) + 1); added++; }
                        }
                        done.put(track, doneTrack); completedAt.put(track, trackDates);
                        state.put("done", done); state.put("completedAt", completedAt); state.put("activity", activity);
                        current.put("status", "finished"); current.put("submitted", checked); current.put("finishedAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date()));
                        JSONArray history = goals.optJSONArray("history"); if (history == null) history = new JSONArray();
                        int total = current.optJSONArray("items") == null ? 0 : current.getJSONArray("items").length();
                        JSONObject record = new JSONObject(); record.put("date", goalDate); record.put("track", track); record.put("total", total); record.put("completed", checked.length()); record.put("percent", total == 0 ? 0 : Math.round(checked.length() * 100f / total)); record.put("reason", "auto-3am");
                        boolean replaced = false;
                        for (int i = 0; i < history.length(); i++) if (goalDate.equals(history.getJSONObject(i).optString("date"))) { history.put(i, record); replaced = true; break; }
                        if (!replaced) history.put(record);
                        goals.put("history", history); state.put("dailyGoals", goals);
                        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(STATE_KEY, state.toString()).apply();
                    }
                }
            }
        } catch (Exception ignored) { }
        scheduleNext(context);
    }
}
