# Study Tracker Android App

This project wraps the supplied Study Tracker HTML as an offline Android WebView app. The HTML is bundled in `app/src/main/assets/index.html`.

## Build APK using GitHub Actions (no Android Studio needed)
1. Create a GitHub account if you do not already have one.
2. Create a new repository on GitHub.
3. Upload the **contents** of this `StudyTrackerAndroid` folder to the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab.
5. Select **Build Study Tracker APK** and press **Run workflow**.
6. When the workflow finishes successfully, open that run and download the artifact named **Study-Tracker-debug-APK**. Inside it is `app-debug.apk`.
7. Open the APK on your Android phone and allow installation from that source if Android asks.

The workflow builds a debug APK. It is suitable for personal installation/testing, not Play Store publishing.

## App details
- Package: `com.studytracker.app`
- Minimum Android: 6.0 (API 23)
- Offline HTML app; original screens, styling and tracker logic are bundled locally.
- Progress/preferences use the app WebView's localStorage.
- Browser localStorage is separate. Export a JSON backup from the browser version and restore it in the app to transfer existing progress.


## Android launcher icon and navigation updates
- Launcher aliases are provided for every in-app logo, including all four hibiscus flower colors. Hibiscus red is the default launcher icon.
- Selecting a logo in Settings updates the Android launcher icon through the native bridge. Some launchers may take a few seconds to refresh the icon.
- The app uses the custom in-app splash as its visible splash; the Android launch window uses the same dark background to avoid a second prominent splash.
- Content is kept below system bars, and non-home pages include Back and Home controls.


## Latest UI fixes
- Admission Info now shows a single contextual Add Information button (empty state or after the saved entries).
- Admission dates are displayed as DD-MM-YYYY and saved admission cards use a more compact height.
- Logo box colors are stored per selected logo, preview live while selecting colors, and apply to the logo tile and app logo surfaces.
- The three-dot menu includes an Incomplete Goals Message ON/OFF switch.
- At the Bangladesh 3:00 AM rollover, checked chapters are submitted to the Tracker; unchecked chapter names are saved for a one-time popup when the app is next opened (only while the switch is ON).
